import tkinter

root = tk()

root.mainloop()